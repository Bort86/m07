<?php

require_once "controller/ControllerInterface.php";
require_once "view/ProductView.class.php";
require_once "model/ProductModel.class.php";
require_once "model/Product.class.php";
require_once "util/ProductMessage.class.php";
//require_once "util/ProductFormValidation.class.php";

class ProductController implements ControllerInterface {

    private $view;
    private $model;

    public function __construct() {
        // carga la vista
        $this->view = new ProductView();

        // carga el modelo de datos
        $this->model = new ProductModel();
    }

    public function processRequest() {

        $request = NULL;
        $_SESSION['info'] = array();
        $_SESSION['error'] = array();

        // recupera la acción de un formulario
        if (filter_has_var(INPUT_POST, 'action')) {
            $request = filter_has_var(INPUT_POST, 'action') ? filter_input(INPUT_POST, 'action') : NULL;
        }
        // recupera la opción de un menú
        else {
            $request = filter_has_var(INPUT_GET, 'option') ? filter_input(INPUT_GET, 'option') : NULL;
        }

        switch ($request) {
            case "list_all":
                $this->listAll();
                break;
            case "form_add":
                $this->form_add();
                break;
            default:
                $this->view->display();
        }
    }
    
    public function listAll() {
         $products=$this->model->listAll();
         if (!empty($products)) {
             $_SESSION['info']=ProductMessage::INF_FORM['found'];
         }
         else {
            $_SESSION['error']=ProductMessage::ERR_FORM['not_found'];
        }
        $this->view->display("view/form/ProductList.php", $products);
    }
    
    public function form_add(){
        $categories = $this->model->listCategories();
        $this->view->display("view/form/ProductFormAdd.php",NULL,$categories);
    }

    public function add() {
        
    }

    public function delete() {
        
    }

    

    public function modify() {
        
    }

    public function searchById() {
        
    }

}
