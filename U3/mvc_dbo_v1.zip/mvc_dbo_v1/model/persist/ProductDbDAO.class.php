<?php

require_once "model/persist/ConnectDb.class.php";

class ProductDbDAO {

    private static $instance = NULL; // instancia de la clase
    private $connect; // conexión actual

    public function __construct() {
        $this->connect = (new ConnectDb())->getConnection();
    }

    public static function getInstance(): ProductDbDAO {
        if (self::$instance == NULL) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    public function listAll(): array {
        $result = array();

        if ($this->connect == NULL) {
            $_SESSION['error'] = "Unable to connect to database";
            return $result;
        };

        try {
            $sql = <<<SQL
                SELECT id,name,price,description,category FROM product;
SQL;

            $stmt = $this->connect->query($sql); // devuelve los datos

            $stmt->setFetchMode(PDO::FETCH_CLASS | PDO::FETCH_PROPS_LATE, 'Product');

            $result = $stmt->fetchAll();
            
            return $result;
            
        } catch (PDOException $e) {
 
            return $result;
        }
    }

}
