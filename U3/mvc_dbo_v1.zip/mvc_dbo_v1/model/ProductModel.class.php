<?php
require_once "model/persist/ProductDbDAO.class.php";

class ProductModel {

    private $dataProduct;

    public function __construct() {
        
        $this->dataProduct = ProductDbDAO::getInstance();
        
    }
    
    public function listAll():array {
        $result=array();
        //dataProduct instancia de la clase DAO
        $products=$this->dataProduct->listAll();
        
        
        $categoryModel = new CategoryModel();
        
        foreach ($products as $product){
            $category=$categoryModel->searchById($product->getCategory());
            
            if(isset($category)){
                
                $product->setCategory($category);
                
            }
            else{
                
                $product->setCategory(new Category);
                
            }
            
            array_push($result, $product);
        }
        
        return $result;
    }
    
    public function listCategories(): array{
        
        $categoryModel = new CategoryModel();
        $result = $categoryModel->listAll();
        
        return $result;
    }

}
