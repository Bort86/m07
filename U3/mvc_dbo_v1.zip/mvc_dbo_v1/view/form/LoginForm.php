<div id="content">
    <form method="post" action="">
        <fieldset>
            <legend>Login</legend>
            <label>User *:</label>
            <input type="text" placeholder="Username" name="username" value="" />
            <label>Password *:</label>
            <input type="password" placeholder="Password" name="password" value="" />

            <label>* Required fields</label>
            <input type="submit" name="action" value="login" />
        </fieldset>
    </form>
</div>
